package t3a5;

public class Cuenta {
    private String numeroCuenta;
    private int pin;
    private float saldo;
    
    public Cuenta() {}
    

    public String getNumeroCuenta() {
        return numeroCuenta;
    }
    
    public void consultarSaldo(){
        saldo = 656.50f;
        System.out.println("Tienes un saldo de: " + getSaldo());
    }
    
    public void estadoDeCuenta(){
        System.out.println("ESTADO DE CUENTA\n\n"
                + "cuenta : " + getNumeroCuenta()
                + "\nSaldo: " + getSaldo()
                + "\n\nUltimosmovimientos");
    }
    
    public void retirarEfectivo() {
        if (getSaldo() > 0){
            System.out.println("�Cuanto desea retirar?");
        } else {
            System.out.println("NO PUEDO AYUDARTE CON ESTA OPERACION"
                    + "FONDOS INSUFICIENTES");
        }
    }
    
    public void seguros(){
        System.out.println("SEGUROS"
                + "\n1. Seguro de tu auto"
                + "\n2. Seguro de vida"
                + "\n3. Seguro medico"
                + "\n4. Seguro de vivienda");
    }
    
    public void creditos(){
        System.out.println("CREDITOS"
                + "\n1. Hipotecario"
                + "\n2. Crediauto"
                + "\n3. Familiar"
                + "\n4. Personal");
    }
    
    public void salir(){
        System.err.println("Gracias. Regrese pronto");
    }
    
    @Override
    public String toString(){
        String mensaje = "Numero de cuenta: " + numeroCuenta;
        return mensaje;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
            
    
}
